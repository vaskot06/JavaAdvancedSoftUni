package heroRepository;

public class Main {
    public static void main(String[] args) {

        Item item = new Item(25, 22, 222);
        System.out.println(item);

    }
}

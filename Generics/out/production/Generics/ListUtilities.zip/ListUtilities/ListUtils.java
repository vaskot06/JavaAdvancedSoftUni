package ListUtilities;

import java.util.Comparator;
import java.util.List;

public class ListUtils<T extends Comparable<T>> {

    public T getMin(List<T> list) {
        T min = null;
        if (list.size() == 0) {
            throw new IllegalArgumentException();
        } else {
            min = list.stream().min(Comparable::compareTo).stream().findFirst().get();
        }

        return min;
    }

    public T getMax(List<T> list) {
        T max = null;
        if (list.size() == 0) {
            throw new IllegalArgumentException();
        } else {
            max = list.stream().max(Comparator.naturalOrder()).stream().findFirst().get();
        }

        return max;
    }
}

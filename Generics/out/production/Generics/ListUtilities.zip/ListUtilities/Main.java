package ListUtilities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        List<Integer> integerList = new ArrayList<>();
        Collections.addAll(integerList, 1 ,3, 4, 5,-1654645,2444,21);

        ListUtils<Integer> listUtils = new ListUtils<>();

        System.out.println(listUtils.getMax(integerList));
    }
}
